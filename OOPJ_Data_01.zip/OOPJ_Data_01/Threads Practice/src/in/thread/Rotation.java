package in.thread;
import java.util.Scanner;

public class Rotation {

	public static void main(String[] args) {
	
		
		 Scanner sc=new Scanner(System.in);
	        int n = sc.nextInt();
	        int d = sc.nextInt();
	        int arr[]=new int[5];
	        
	        for (int i=0;i<=5;i++){
	          sc.nextInt();
	        }
	        for(int i = 0;i<=i;i++)
	            for(int j=0;j<=j;j++){
	                int temp=i;
	                i=j;
	                j=temp;
	            }
	              System.out.println(arr);  
	        
	    }
	}

